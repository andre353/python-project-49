import random


def generate_rand_num():
    return random.randint(0, 100)
