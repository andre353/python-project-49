import random


def generate_rand_num(a=0, b=100):
    return random.randint(a, b)
