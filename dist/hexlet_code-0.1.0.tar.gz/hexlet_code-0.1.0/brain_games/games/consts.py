GREETING_PHRASE = 'Welcome to the Brain Games!'
ROUNDS_TOTAL = 3
