# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games',
 'brain_games.games',
 'brain_games.games.game_calc',
 'brain_games.games.game_even',
 'brain_games.games.game_gcd',
 'brain_games.games.game_prime',
 'brain_games.games.game_progression',
 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Brain Games is a 5 simple terminal serie of games.',
    'long_description': '# **Brain Games**\n---\n### Hexlet tests and linter status:\n[![Actions Status](https://github.com/andre353/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/andre353/python-project-49/actions)\n### Maintainability as per Codeclimate service:\n[![Maintainability](https://api.codeclimate.com/v1/badges/12cbe4333a83657869fb/maintainability)](https://codeclimate.com/github/andre353/python-project-49/maintainability)\n## Description\n---\n**Brain Games** is a serie of simple terminal games. The player is asked 3 questions in a row. He or she is to answer each question right in order to win. Here is a list of all brain games with a video description linked to each one:\n- [Brain Even](https://asciinema.org/a/536594) A number is provided. Define if it is even. To run the game:\n    `brain-even`\n\n- [Brain Calc](https://asciinema.org/a/AHLpki1ER7BV7bW4nDarasmDO) Calculate the two provided numbers. To run the game:\n    `brain-calc`\n\n- [Brain Gcd](https://asciinema.org/a/IJijVkmGzzjqBXN1jeOe8SgVM) Two numbers are provided. Define the largest common divisor. To run the game:\n    `brain-gcd`\n\n- [Brain Progression](https://asciinema.org/a/03XxsX5kRSb9qe0p8szq6nqYS) A 5-10 numbers progression is provided. Define the missing element. To run the game:\n    `brain-progression`\n\n- [Brain Prime](https://asciinema.org/a/lnMCobhonfYPdPE3eUyXAd6Jw) A number is provided. Define if it is prime. To run the game:\n    `brain-prime`\n\n## Installation\n---\n### [Python 3.8.0 +](https://www.python.org/downloads/)\n### [Pip 20.02.2 +](https://pip.pypa.io/en/stable/cli/pip_install/)\n    python3 -m pip --version\n### [Poetry](https://python-poetry.org/docs/)\n    poetry\n    poetry config virtualenvs.in-project true\n### Clone Package\n    git@github.com:andre353/python-project-49.git\n### Settings\n    cd python-project-49/\n    make build\n    make package-install\n',
    'author': 'Elena',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/andre353/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
