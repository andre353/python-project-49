# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/andre353/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/andre353/python-project-49/actions)\n### Maintainability\n[![Maintainability](https://api.codeclimate.com/v1/badges/12cbe4333a83657869fb/maintainability)](https://codeclimate.com/github/andre353/python-project-49/maintainability)\n### asciinema\n### brain-even\n[![asciicast](https://asciinema.org/a/536594.svg)](https://asciinema.org/a/536594)\n### brain-calc\n[![asciicast](https://asciinema.org/a/AHLpki1ER7BV7bW4nDarasmDO.svg)](https://asciinema.org/a/AHLpki1ER7BV7bW4nDarasmDO)\n### brain-gcd\n[![asciicast](https://asciinema.org/a/IJijVkmGzzjqBXN1jeOe8SgVM.svg)](https://asciinema.org/a/IJijVkmGzzjqBXN1jeOe8SgVM)\n### brain-progression\n[![asciicast](https://asciinema.org/a/03XxsX5kRSb9qe0p8szq6nqYS.svg)](https://asciinema.org/a/03XxsX5kRSb9qe0p8szq6nqYS)',
    'author': 'Elena',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
